# Extensiones Oficiales de Prism para Editores e IDEs

Prism cuenta con extensiones y paquetes de soporte de sintaxis para los principales editores y entornos de desarrollo (IDEs) utilizados en el ecosistema Java y desarrollo de software:

| Editor / IDE | Tipo de Soporte | Paquete Generado | Ubicacion |
| :--- | :--- | :--- | :--- |
| **Visual Studio Code** | Extension VSIX oficial | `prism-lang-1.0.2.vsix` | [`extensions/prism/`](file:///home/angel/Documentos/Prism/extensions/prism/) |
| **IntelliJ IDEA / JetBrains** | Plugin & TextMate Bundle | `prism-intellij-1.0.0.zip` / `prism-textmate-bundle.zip` | [`extensions/intellij/`](file:///home/angel/Documentos/Prism/extensions/intellij/) |
| **Eclipse IDE** | Plugin OSGi (Dropin) / TM4E | `org.prism.lang_1.0.0.jar` | [`extensions/eclipse/`](file:///home/angel/Documentos/Prism/extensions/eclipse/) |
| **Apache NetBeans** | Modulo MIME & TextMate | `org-prism-lang-1.0.0.jar` / `prism-netbeans-1.0.0.zip` | [`extensions/netbeans/`](file:///home/angel/Documentos/Prism/extensions/netbeans/) |

---

## 1. Visual Studio Code
* **Instalacion directa desde Marketplace**:
  ```text
  ext install absoftwaregroup.prism-lang
  ```
* **Instalacion manual (.vsix)**:
  `code --install-extension dist/prism-lang-1.0.2.vsix`

---

## 2. IntelliJ IDEA / JetBrains (PyCharm, Android Studio, CLion)
* **Metodo A (TextMate Bundle directo, 30 segundos)**:
  1. En IntelliJ IDEA, ve a **Settings** (`Ctrl + Alt + S`) -> **Editor** -> **TextMate Bundles**.
  2. Presiona el boton **`+`** (Add).
  3. Selecciona la carpeta [`extensions/intellij/`](file:///home/angel/Documentos/Prism/extensions/intellij/) o el archivo `dist/prism-textmate-bundle.zip`.
  4. Presiona **Apply** y **OK**.
* **Metodo B (Plugin desde disco)**:
  1. Ve a **Settings** -> **Plugins**.
  2. Haz clic en el engranaje y selecciona **Install Plugin from Disk...**.
  3. Selecciona `dist/prism-intellij-1.0.0.zip`.

---

## 3. Eclipse IDE
* **Instalacion mediante dropins (Recomendado)**:
  1. Copia el archivo `dist/org.prism.lang_1.0.0.jar` dentro del directorio `dropins/` de tu instalacion de Eclipse.
  2. Inicia o reinicia Eclipse.
  3. Los archivos `.pr` se reconoceran automaticamente y se abriran con el Generic Editor con resaltado de sintaxis de Prism.

---

## 4. Apache NetBeans (v12 a v20+)
* **Metodo A (TextMate Lexer integrado)**:
  1. En NetBeans, ve a **Tools** -> **Options** -> **Editor** -> **Language Servers** / **Grammars**.
  2. Vincula la extension `.pr` con el archivo de gramatica `syntaxes/prism.tmLanguage.json`.
* **Metodo B (Modulo de extensiones)**:
  1. Ve a **Tools** -> **Plugins** -> pestana **Downloaded**.
  2. Haz clic en **Add Plugins...** y selecciona `dist/org-prism-lang-1.0.0.jar`.
  3. Haz clic en **Install**.

